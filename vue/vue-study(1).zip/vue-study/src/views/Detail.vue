<template>
    <div>
        <p>{{$route.params.id}}</p>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>
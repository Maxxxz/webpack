小程序 浏览器运行

1. 浏览器渲染  硬件加速

    Chrome 事件 微任务==> 同步执行

2. 小程序底层架构实现 wxml wxss js


3. 小程序代码实现浏览器运行




1. 解析dom  dom Tree
2. css Tree 
3. layout tree
4. js
渲染



浏览器进程
    ui  ==>
    网络    跨域？ DNS TCP TLS MIME
    文件 
渲染进程  
    合成线程  处理事件是否需要经过主线  blink
        接受事件，判断是否需要主线程参与
    主线程    运行环境 V8=>js  html\css渲染引擎  GC==> v8 
     1. requestAnimationFrame
     2. parse html    dom Tree 
     3. css parse     css Tree
        微任务是在结构阶段同步执行
        https://html.spec.whatwg.org/multipage/webappapis.html#event-loop-processing-model
    
    4. layout Tree 
        位置 大小 内容
        先后顺序
    5. layer Tree

    6. paint 
        layer==> 数据 
        绘图指令 ==> 绘制记录表 

    
        
    tile work
GPU 
    GPU



js线程  html

深度优先 

广度优先 

构造 
class A{
    constructor(){

    }
    ~A(){

    }
}

析构 


元素节点
1. 边框 背景  子元素 {其他元素、文本、图片}



fiber 可中断